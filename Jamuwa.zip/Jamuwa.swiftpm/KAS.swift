import SwiftUI
import AVFoundation

struct KASView: View {
    @State private var KABowlOffset = CGSize.zero
    @State private var KABowlOpacity = 1.0
    @State private var PourComplete = false
    @State private var strainerIndex = 0
    @State private var GoalComplete = false
    @State private var showThirdView = false
    
    let strainerImages = ["KStrainer5", "KStrainer4", "KStrainer3", "KStrainer2", "KStrainer1","EmptyStrainer"]
    let KAImages = ["EmptyCup","KA1","KA2","KA3","KA4","KA5"]
    
    var body: some View {
        ZStack{
            Image("BKSbg")
                .resizable()
                .scaledToFill()
            
            Image("EmptyStrainer")
                .resizable()
                .frame(width: 960, height: 720)
                .position(x: 790, y: 225)
            
            Image("KABowl")
                .resizable()
                .frame(width: 600,height: 450)
                .position(x: 245,y: 550)
                .opacity(KABowlOpacity)
                .offset(KABowlOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.KABowlOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 575, y: 150, width: 300, height: 300) 
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.KABowlOpacity = 0.0
                                    checkPourCompletion()
                                }
                            }
                            self.KABowlOffset = .zero
                        }
                    
                )
            Image("EmptyCup")
                .resizable()
                .frame(width: 900, height: 675)
                .position(x: 680, y: 500)
            
            if PourComplete{
                    Image(strainerImages[strainerIndex])
                        .resizable()
                        .frame(width: 960, height: 720)
                        .position(x: 790, y: 225)
                        .onTapGesture {
                            if strainerIndex < strainerImages.count - 1 {
                                strainerIndex += 1
                                checkGoalCompletion()
                            }
                        }
                    Image(KAImages[strainerIndex])
                        .resizable()
                        .frame(width: 900, height: 675)
                        .position(x: 680, y: 500)
                        .offset()
                
            }
            
            
            if GoalComplete {
                ZStack{
                    Image("TWLast")
                        .resizable()
                        .frame(width: 700, height: 700)
                    VStack {
                        Text("Congratulations🥳")
                            .font(.largeTitle)
                        Spacer().frame(height: 50)
                        Text("Here is your Jamu Beras Kencur")
                            .font(.largeTitle)
                        Spacer().frame(height:450)
                        NavigationLink(destination: ThirdView()) {
                            Text("Make another Jamu ?")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                                .padding()
                                .padding(.horizontal, 20)
                                .background(
                                    Color.brown
                                        .cornerRadius(10)
                                        .shadow(
                                            color: Color.black.opacity(0.2), radius: 10)
                                )
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    .padding()
                }
                
            }
            
            
        }.edgesIgnoringSafeArea(.all)
    }
    
    func checkPourCompletion(){
        if KABowlOpacity == 0.0{
            PourComplete = true
        }
    }
    
    func checkGoalCompletion(){
        if strainerIndex == strainerImages.count - 1{
            GoalComplete = true
        }
    }
    
}
