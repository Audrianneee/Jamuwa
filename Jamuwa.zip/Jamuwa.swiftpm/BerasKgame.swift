import SwiftUI
import AVFoundation

struct BerasKgame: View {
    @State private var isShowingSheet = false
    @State private var isCongratsSheet = false
    @State private var RiceOffset = CGSize.zero
    @State private var RiceOpacity = 1.0
    @State private var SugarOffset = CGSize.zero
    @State private var SugarOpacity = 1.0
    @State private var WaterOffset = CGSize.zero
    @State private var WaterOpacity = 1.0
    @State private var GingerOffset = CGSize.zero
    @State private var GingerOpacity = 1.0
    @State private var KencurOffset = CGSize.zero
    @State private var KencurOpacity = 1.0
    @State private var CutKencurOffset = CGSize.zero
    @State private var CutKencurOpacity = 1.0
    @State private var BlendOffset = CGSize.zero
    @State private var BlendOpacity = 1.0
    @State private var PotOffset = CGSize.zero
    @State private var PotOpacity = 1.0
    @State private var boilComplete = false
    @State private var cutComplete = false
    @State private var blendComplete = false
    @State private var bowlComplete = false
    @State private var isShowFire = false
    @State private var isShowPot = false
    @State private var showCongratsSheet = false
    @State private var showBKSview = false

    var body: some View {
        ZStack{
            Image("Gamebg")
                .resizable()
                .scaledToFill()
            
            Button(action: {
                isShowingSheet.toggle()
            }) {
                Text("INSTRUCTIONS")
                    .fontWeight(.bold)
                    .font(.system(size: 20))
                    .foregroundColor(.brown)
            }.position(x:1080,y:80)
                .sheet(isPresented: $isShowingSheet,
                       onDismiss: didDismiss) {
                    VStack {
                        Text("Instructions")
                            .font(.system(size:50))
                            .fontWeight(.bold)
                            .foregroundColor(.brown)
                        Text("""
                        1. Peel and cut the kencur (drag the kencur to the cutting board)
                    
                    
                        2. Boil the sugar and ginger with water. Wait for a while.
                    
                    
                        3. Blend the cut kencur, rice, boiled sugar and ginger all together
                    
                    
                        4. Put the blend into the bowl
                    """)
                        .padding(50)
                        .font(.system(size:20))
                        .foregroundColor(.brown)
                        .fontWeight(.bold)
                        Button("Dismiss",
                               action: { isShowingSheet.toggle() })
                        .foregroundColor(.brown)
                    }
                }
            
            Image("CuttingBoard")
                .resizable()
                .frame(width: 400, height: 300)
                .position(x: 590,y: 360)
            
            if boilComplete {
                ZStack{
                    if isShowFire && isShowPot {
                        Image("Pot")
                            .resizable()
                            .frame(width: 600, height: 500)
                            .position(x: 595, y: 650)
                            .onAppear(){
                                DispatchQueue.main.asyncAfter(deadline: .now() + 5){
                                    isShowPot = false
                                }
                            }
                        Image("flame") 
                            .resizable()
                            .frame(width: 700, height: 500)
                            .position(x: 595, y: 650)
                            .onAppear(){
                                DispatchQueue.main.asyncAfter(deadline: .now() + 4){
                                    isShowFire = false
                                }
                            }
                    }else{
                        Image("SmokePot")
                            .resizable()
                            .frame(width: 550, height: 450)
                            .position(x: 595, y: 640)
                            .opacity(PotOpacity)
                            .offset(PotOffset)
                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        self.PotOffset = value.translation
                                    }
                                    .onEnded { value in
                                        let dropArea = CGRect(x: 900, y: 200, width: 300, height: 300)
                                        if dropArea.contains(value.location) {
                                            withAnimation {
                                                self.PotOpacity = 0.0
                                                checkBlendCompletion()
                                            }
                                        }
                                        self.PotOffset = .zero
                                    }
                            )
                        
                    }
                }.onAppear{
                    isShowFire = true
                    isShowPot = true
                }
            }else{
                Image("Pot")
                    .resizable()
                    .frame(width: 600, height: 500)
                    .position(x: 595, y: 650)
            }
            
            Image("Water")
                .resizable()
                .frame(width: 300,height: 240)
                .position(x: 225,y: 425)
                .opacity(WaterOpacity)
                .offset(WaterOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.WaterOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 450, y: 500, width: 300, height: 300)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.WaterOpacity = 0.0
                                    checkBoilCompletion()
                                }
                            }
                            self.WaterOffset = .zero
                        }
                    
                )
            
            Image("Sugar")
                .resizable()
                .frame(width: 300,height: 250)
                .position(x: 225,y: 575)
                .opacity(SugarOpacity)
                .offset(SugarOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.SugarOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 450, y: 500, width: 300, height: 300) 
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.SugarOpacity = 0.0
                                    checkBoilCompletion()
                                }
                            }
                            self.SugarOffset = .zero
                        }
                    
                )
            
            Image("Ginger")
                .resizable()
                .frame(width: 300,height: 250)
                .position(x: 130,y: 715)
                .opacity(GingerOpacity)
                .offset(GingerOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.GingerOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 450, y: 500, width: 300, height: 300) 
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.GingerOpacity = 0.0
                                    checkBoilCompletion()
                                }
                            }
                            self.GingerOffset = .zero
                        }
                    
                )
    
            Image("Kencur")
                .resizable()
                .frame(width: 300,height: 250)
                .position(x: 290,y: 700)
                .opacity(KencurOpacity)
                .offset(KencurOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.KencurOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 450, y: 200, width: 300, height: 300) 
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.KencurOpacity = 0.0
                                    checkCutCompletion()
                                }
                            }
                            self.KencurOffset = .zero
                        }
                    
                )
            Image("EmptyBowl")
                .resizable()
                .frame(width: 400,height: 300)
                .position(x: 965,y: 675)
            
            if blendComplete {
                Image("Pot")
                    .resizable()
                    .frame(width: 600, height: 500)
                    .position(x: 595, y: 650)
                Image("BFilling") 
                    .resizable()
                    .frame(width: 460, height: 360)
                    .position(x: 970, y: 367)
                    .opacity(BlendOpacity)
                    .offset(BlendOffset)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                self.BlendOffset = value.translation
                            }
                            .onEnded { value in
                                let dropArea = CGRect(x: 900, y: 650, width: 300, height: 300) 
                                if dropArea.contains(value.location) {
                                    withAnimation {
                                        self.BlendOpacity = 0.0
                                        checkBowlCompletion()
                                    }
                                }
                                self.BlendOffset = .zero
                            }
                        
                    )
            }else{
                Image("Blender")
                    .resizable()
                    .frame(width: 460, height: 360)
                    .position(x: 970, y: 367)
            }
            
            Image("Rice")
                .resizable()
                .frame(width: 300,height: 250)
                .position(x: 225,y: 315)
                .opacity(RiceOpacity)
                .offset(RiceOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.RiceOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 900, y: 200, width: 200, height: 200)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.RiceOpacity = 0.0
                                    checkBlendCompletion()
                                }
                            }
                            self.RiceOffset = .zero
                        }
                    
                )
            
            if cutComplete {
                Image("KencurCut")
                    .resizable()
                    .frame(width: 400, height: 300)
                    .position(x: 600,y: 350)
                    .opacity(CutKencurOpacity)
                    .offset(CutKencurOffset)
                    .gesture(
                        DragGesture()
                            .onChanged { value in 
                                self.CutKencurOffset = value.translation
                            }
                            .onEnded { value in
                                let dropArea = CGRect(x: 900, y: 200, width: 300, height: 300)
                                if dropArea.contains(value.location) {
                                    withAnimation {
                                        self.CutKencurOpacity = 0.0
                                        checkBlendCompletion()
                                    }
                                }
                                self.CutKencurOffset = .zero
                            }
                        
                    )
            }
            
            
            if bowlComplete{
                Image("BKBowl") 
                    .resizable()
                    .frame(width: 400, height: 300)
                    .position(x: 965, y: 675)
                Image("Blender")
                    .resizable()
                    .frame(width: 460, height: 360)
                    .position(x: 970, y: 367)
                
                    if showBKSview{
                        BKS()
                    }
                    VStack {
                        Button("Show Congratulations") {
                            showCongratsSheet = true
                        }
                        .padding()
                        .position(x: 100, y: 100)
                        .opacity(0.0)
                    }
                    .sheet(isPresented: $showCongratsSheet) {
                        CongratulationsView(showCongratsSheet: $showCongratsSheet, showBKSview: $showBKSview)
                    }
                
             }
            
        } .edgesIgnoringSafeArea(.all)
          .onAppear {
              isShowingSheet = true 
          }
    }
    
    
    func checkBoilCompletion() {
        if SugarOpacity == 0.0 && WaterOpacity == 0.0 && GingerOpacity == 0.0  {
            boilComplete = true
        }
    }
    
    func checkCutCompletion() {
        if KencurOpacity == 0.0 {
            cutComplete = true
        }
    }
    
    func checkBlendCompletion(){
        if RiceOpacity == 0.0 && CutKencurOpacity == 0.0 && PotOpacity == 0.0 {
            blendComplete = true
        }
    }
    
    func checkBowlCompletion(){
        if BlendOpacity == 0.0{
            bowlComplete = true
            showCongratsSheet = true
        }
    }
    
    func didDismiss() {
    }
}

