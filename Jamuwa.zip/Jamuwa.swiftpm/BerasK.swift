import SwiftUI
import AVFoundation

struct BerasK: View {
    @State private var isBerasKgamePresented = false
    
    var body: some View {
            VStack {
                Image("BKbg") 
                    .resizable()
                    .scaledToFill()
                    .overlay(
                        VStack {
                            NavigationLink(destination: BerasKgame()){
                                Text("Next".uppercased())
                                    .font(.system(size: 40))
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .padding(.horizontal, 20)
                                    .background(
                                        Color.brown
                                            .cornerRadius(10)
                                            .shadow(
                                                color: Color.black.opacity(0.2), radius: 10)
                                    )
                                    .scaleEffect(isBerasKgamePresented ? 1.2 : 1.0)
                                    .onAppear {
                                        withAnimation(Animation.easeInOut(duration: 1.5).repeatForever()) {
                                            self.isBerasKgamePresented.toggle()
                                        }
                                    }
                            }.position(x:900,y:-130)
                            .padding(20)
                                .padding(.bottom,100)
                        }.padding(.bottom)
                            .padding(.top,750)
                    )
            } .edgesIgnoringSafeArea(.all)
    }
}
