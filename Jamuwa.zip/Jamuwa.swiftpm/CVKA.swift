import SwiftUI
import AVFoundation

struct CVKAView: View {
    @Binding var showCVKA: Bool
    @Binding var showKAS : Bool
    
    var body: some View {
        NavigationView{
            ZStack {
                Image("Grater")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 380, height: 320)
                    .position(x: 100, y :160)
                
                Image("Sugar")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 360, height: 280)
                    .position(x: 330, y :140)
                
                Image("Tamarind")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 420, height: 330)
                    .position(x: 575, y :150)
                
                Image("Kunyit")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 400, height: 300)
                    .position(x: 125, y :575)
                
                Image("Pot")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 480, height: 360)
                    .position(x: 320, y :625)
                
                Image("Salt")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 300, height: 225)
                    .position(x: 575, y :625)
                
                VStack {
                    Text("Congratulations!🥳")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.brown)
                        .padding()
                    Text("You completed the task!")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.brown)
                        .padding()
                    Text("Let's move on to the last part!")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.brown)
                        .padding()
                    
                    
                    
                    Button("Next",action: { 
                        showKAS = true
                        showCVKA = false
                    })
                    .font(.system(size: 30))
                    .foregroundColor(.white)
                    .padding()
                    .padding(.horizontal, 20)
                    .background(
                        Color.brown
                            .cornerRadius(10)
                            .shadow(
                                color: Color.black.opacity(0.2), radius: 10)
                    )
                    
                    
                }
            }
        }
        
    }
}

