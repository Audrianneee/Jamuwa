import SwiftUI
import AVFoundation

struct CVTW: View {
    @Binding var showCVTW: Bool
    @Binding var showTWS : Bool
    
    var body: some View {
        NavigationView{
            ZStack {
                Image("Blender")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 380, height: 320)
                    .position(x: 100, y :150)
                
                Image("Sugar")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 360, height: 280)
                    .position(x: 330, y :140)
                
                Image("Ginger")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 420, height: 330)
                    .position(x: 575, y :150)
                
                Image("Kencur")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 400, height: 300)
                    .position(x: 125, y :575)
                
                Image("Pot")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 480, height: 360)
                    .position(x: 320, y :625)
                
                Image("Rice")
                    .resizable()
                    .opacity(0.5)
                    .frame(width: 480, height: 360)
                    .position(x: 575, y :625)
                
                VStack {
                    Text("Congratulations!🥳")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.brown)
                        .padding()
                    Text("You completed the task!")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.brown)
                        .padding()
                    Text("Let's move on to the last part!")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.brown)
                        .padding()
                    
                    
                    
                    Button("Next",action: { 
                        showTWS = true
                        showCVTW = false
                    })
                    .font(.system(size: 30))
                    .foregroundColor(.white)
                    .padding()
                    .padding(.horizontal, 20)
                    .background(
                        Color.brown
                            .cornerRadius(10)
                            .shadow(
                                color: Color.black.opacity(0.2), radius: 10)
                    )
                    
                    
                }
            }
        }
        
    }
}

