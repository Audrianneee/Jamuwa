import SwiftUI
import AVFoundation

struct ThirdView: View {
  
    var body: some View {
            VStack {
                Image("TVbg") 
                    .resizable()
                    .scaledToFill()
                    .overlay(
                        HStack(spacing :40){
                            VStack{
                                NavigationLink(destination: BerasK()){
                                    Text("Beras Kencur".uppercased())
                                        .font(.system(size: 30))
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .padding()
                                        .padding(.horizontal, 20)
                                        .background(
                                            Color.brown
                                                .cornerRadius(10)
                                                .shadow(
                                                    color: Color.black.opacity(0.2), radius: 10)
                                        )
                                }.position(x:175,y:0)
                                    .padding(.bottom, 100)
                            }.padding(.bottom)
                                .padding(.top,750)
                            
                            VStack{
                                NavigationLink(destination: KunyitA()){
                                    Text("Kunyit Asam".uppercased())
                                        .font(.system(size: 30))
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .padding()
                                        .padding(.horizontal, 20)
                                        .background(
                                            Color.brown
                                                .cornerRadius(10)
                                                .shadow(
                                                    color: Color.black.opacity(0.2), radius: 10)
                                        )
                                }.position(x:150,y:0)
                            }.padding(.bottom)
                                .padding(20)
                                .padding(.bottom, 100)
                                .padding(.top,750)
                    
                            VStack{
                                NavigationLink(destination: Temulawak()){
                                    Text("Temulawak".uppercased())
                                        .font(.system(size: 30))
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                        .padding()
                                        .padding(.horizontal, 20)
                                        .background(
                                            Color.brown
                                                .cornerRadius(10)
                                                .shadow(
                                                    color: Color.black.opacity(0.2), radius: 10)
                                        )
                                }.position(x:150,y:0)
                                .padding(20)
                                    .padding(.bottom, 100)
                            }.padding(.bottom)
                                .padding(.top,750)
                                
                        }.edgesIgnoringSafeArea(.all))
            }.edgesIgnoringSafeArea(.all)
    }
}


