import SwiftUI
import AVFoundation

struct Temulawakgame: View {
    @State private var isShowingSheet = false
    @State private var SugarOffset = CGSize.zero
    @State private var SugarOpacity = 1.0
    @State private var TemulawakOffset = CGSize.zero
    @State private var TemulawakOpacity = 1.0
    @State private var HoneyOffset = CGSize.zero
    @State private var HoneyOpacity = 1.0
    @State private var WaterOffset = CGSize.zero
    @State private var WaterOpacity = 1.0
    @State private var PotOffset = CGSize.zero
    @State private var PotOpacity = 1.0
    @State private var GratedTwOffset = CGSize.zero
    @State private var GratedTwOpacity = 1.0
    @State private var isGratedTwShown = false
    @State private var isShowFire = false
    @State private var isShowPot = false
    @State private var putComplete = false
    @State private var boilComplete = false
    @State private var bowlComplete = false
    @State private var honeyComplete = false
    @State private var isLongPressed = false
    @State private var isGratedTShown = false
    @State private var showCVTW = false
    @State private var showTWS = false
    
    var body: some View {
        ZStack {
            Image("TWgamebg")
                .resizable()
                .scaledToFill()
            
            Button(action: {
                isShowingSheet.toggle()
            }) {
                Text("INSTRUCTIONS")
                    .fontWeight(.bold)
                    .font(.system(size: 20))
                    .foregroundColor(.brown)
            }.position(x:1080,y:80)
                .sheet(isPresented: $isShowingSheet,
                       onDismiss: didDismiss) {
                    VStack {
                        Text("Instructions")
                            .font(.system(size:50))
                            .fontWeight(.bold)
                            .foregroundColor(.brown)
                        Text("""
                        1. Grate the temulawak
                        Hint : long press the grater and tap the bowl
                    
                    
                        2. Boil the grated temulawak with sugar amd water.
                    
                    
                        3. Put the content of the pot into the bowl after it finishes cooking
                    
                    
                        4. Add honey to the bowl to sweeten
                    """)
                        .padding(50)
                        .font(.system(size:20))
                        .foregroundColor(.brown)
                        .fontWeight(.bold)
                        Button("Dismiss",
                               action: { isShowingSheet.toggle() })
                        .foregroundColor(.brown)
                    }
                }
            
            Image("Grater")
                .resizable()
                .frame(width: 600, height: 450)
                .position(x: 580, y: 550)
            
            Image("EmptyBowl")
                .resizable()
                .frame(width: 400, height: 300)
                .position(x: 970,y: 700)
            
            if boilComplete {
                ZStack{
                    if isShowFire && isShowPot {
                        Image("Pot")
                            .resizable()
                            .frame(width: 600, height: 450)
                            .position(x: 960, y: 400)
                            .onAppear(){
                                DispatchQueue.main.asyncAfter(deadline: .now() + 5){
                                    isShowPot = false
                                }
                            }
                        Image("flame") 
                            .resizable()
                            .frame(width: 700, height: 500)
                            .position(x: 960, y: 390)
                            .onAppear(){
                                DispatchQueue.main.asyncAfter(deadline: .now() + 5){
                                    isShowFire = false
                                }
                            }
                    }else{
                        Image("SmokePot")
                            .resizable()
                            .frame(width: 600, height: 450)
                            .position(x: 960, y: 365)
                            .opacity(PotOpacity)
                            .offset(PotOffset)
                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        self.PotOffset = value.translation
                                    }
                                    .onEnded { value in
                                        let dropArea = CGRect(x: 875, y: 400, width: 300, height: 300)
                                        if dropArea.contains(value.location) {
                                            withAnimation {
                                                self.PotOpacity = 0.0
                                                checkBowlCompletion()
                                                checkHoneyCompletion()
                                            }
                                        }
                                        self.PotOffset = .zero
                                    }
                            )
                        
                    }
                }.onAppear{
                    isShowFire = true
                    isShowPot = true
                }
            }else{
                Image("Pot")
                    .resizable()
                    .frame(width: 600, height: 450)
                    .position(x: 960, y: 400)
            }
            
            Image("Water")
                .resizable()
                .frame(width: 280,height: 210)
                .position(x: 150,y: 300)
                .opacity(WaterOpacity)
                .offset(WaterOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.WaterOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 875, y: 300, width: 350, height: 400)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.WaterOpacity = 0.0
                                    checkBoilCompletion()
                                }
                            }
                            self.WaterOffset = .zero
                        }
                    
                )
            
            Image("Sugar")
                .resizable()
                .frame(width: 280,height: 210)
                .position(x: 285,y: 450)
                .opacity(SugarOpacity)
                .offset(SugarOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.SugarOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 875, y: 300, width: 300, height: 400)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.SugarOpacity = 0.0
                                    checkBoilCompletion()
                                }
                            }
                            self.SugarOffset = .zero
                        }
                    
                )
            
            Image("Temulawak")
                .resizable()
                .frame(width: 280,height: 210)
                .position(x: 150,y: 575)
                .opacity(TemulawakOpacity)
                .offset(TemulawakOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.TemulawakOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 580, y: 250, width: 300, height: 500)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.TemulawakOpacity = 0.0
                                    checkPutCompletion()
                                }
                            }
                            self.TemulawakOffset = .zero
                        }
                    
                )
            
            if putComplete {
                VStack {
                    if isLongPressed {
                        Image("GraterTw") 
                            .resizable()
                            .frame(width: 600, height: 450)
                            .position(x: 580, y: 550)
                            .onTapGesture {
                                isGratedTwShown.toggle()
                            }
                    } else {
                        Image("Grater")
                            .resizable()
                            .frame(width: 600, height: 450)
                            .position(x: 580, y: 550)
                            .gesture(
                                LongPressGesture(minimumDuration: 1.5) 
                                    .onEnded { _ in
                                        isLongPressed.toggle()
                                    }
                            )
                    }
                }
            }
            
            if isGratedTwShown {
                Image("GratedTw")
                    .resizable()
                    .frame(width: 600, height: 450)
                    .position(x: 580, y: 550 )
                    .opacity(GratedTwOpacity)
                    .offset(GratedTwOffset)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                self.GratedTwOffset = value.translation
                            }
                            .onEnded { value in
                                let dropArea = CGRect(x: 875, y: 300, width: 350, height: 400)
                                if dropArea.contains(value.location) {
                                    withAnimation {
                                        self.GratedTwOpacity = 0.0
                                        checkBoilCompletion()
                                    }
                                }
                                self.GratedTwOffset = .zero
                            }
                        
                    )
            }
            
            if bowlComplete{
                Image("TWBowl")
                    .resizable()
                    .frame(width: 400, height: 300)
                    .position(x: 970,y: 700)
            }
            
            Image("Honey")
                .resizable()
                .frame(width: 320,height: 240)
                .position(x: 285,y: 700)
                .opacity(HoneyOpacity)
                .offset(HoneyOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.HoneyOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 875, y: 400, width: 300, height: 300)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.HoneyOpacity = 0.0
                                    checkHoneyCompletion()
                                }
                            }
                            self.HoneyOffset = .zero
                        }
                    
                )
            
            if honeyComplete{               
                if showTWS{
                    TWSView()
                        .onAppear{
                            isLongPressed = false
                            putComplete = false
                        }
                }
                VStack {
                    Button("Show Congratulations") {
                        showCVTW = true
                    }
                    .padding()
                    .position(x: 100, y: 100)
                    .opacity(0.0)
                }
                .sheet(isPresented: $showCVTW) {
                    CVTW(showCVTW: $showCVTW, showTWS: $showTWS)
                }
                
            }
            
        }.edgesIgnoringSafeArea(.all)
            .onAppear{
                isShowingSheet = true
            }
        
    }
    
    func checkBowlCompletion(){
        if PotOpacity == 0 {
            bowlComplete = true
        }
    }
    
    func checkBoilCompletion(){
        if WaterOpacity == 0 && SugarOpacity == 0 && GratedTwOpacity == 0 {
            boilComplete = true
        }
    }
    
    func checkPutCompletion(){
        if TemulawakOpacity == 0 {
            putComplete = true
        }
    }
    
    func checkHoneyCompletion(){
        if HoneyOpacity == 0 && PotOpacity == 0 {
            honeyComplete = true
            showCVTW = true
        }
    }
    func didDismiss() {
    }
}
