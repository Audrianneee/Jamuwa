import SwiftUI
import AVFoundation

struct TWSView: View {
    @State private var TWBowlOffset = CGSize.zero
    @State private var TWBowlOpacity = 1.0
    @State private var PourComplete = false
    @State private var strainerIndex = 0
    @State private var GoalComplete = false
    @State private var showThirdView = false
    
    let strainerImages = ["TWStrainer5", "TWStrainer4", "TWStrainer3", "TWStrainer2", "RWStrainer1","EmptyStrainer"]
    let TWImages = ["EmptyCup","TW1","TW2","TW3","TW4","TW5"]
    
    var body: some View {
        ZStack{
            Image("BKSbg")
                .resizable()
                .scaledToFill()
            
            Image("EmptyStrainer")
                .resizable()
                .frame(width: 960, height: 720)
                .position(x: 790, y: 225)
            
            Image("TWBowl")
                .resizable()
                .frame(width: 600,height: 450)
                .position(x: 245,y: 550)
                .opacity(TWBowlOpacity)
                .offset(TWBowlOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.TWBowlOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 575, y: 150, width: 300, height: 300) 
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.TWBowlOpacity = 0.0
                                    checkPourCompletion()
                                }
                            }
                            self.TWBowlOffset = .zero
                        }
                    
                )
            Image("EmptyCup")
                .resizable()
                .frame(width: 900, height: 675)
                .position(x: 680, y: 500)
            
            if PourComplete{
                Image(strainerImages[strainerIndex])
                    .resizable()
                    .frame(width: 960, height: 720)
                    .position(x: 790, y: 225)
                    .onTapGesture {
                        if strainerIndex < strainerImages.count - 1 {
                            strainerIndex += 1
                            checkGoalCompletion()
                        }
                    }
                Image(TWImages[strainerIndex])
                    .resizable()
                    .frame(width: 900, height: 675)
                    .position(x: 680, y: 500)
                    .offset()
                
            }
            
            
            if GoalComplete {
                ZStack{
                    Image("TWLast")
                        .resizable()
                        .frame(width: 700, height: 700)
                    VStack {
                        Text("Congratulations🥳")
                            .font(.largeTitle)
                        Spacer().frame(height: 50)
                        Text("Here is your Jamu Beras Kencur")
                            .font(.largeTitle)
                        Spacer().frame(height:450)
                        NavigationLink(destination: ThirdView()) {
                            Text("Make another Jamu ?")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                                .padding()
                                .padding(.horizontal, 20)
                                .background(
                                    Color.brown
                                        .cornerRadius(10)
                                        .shadow(
                                            color: Color.black.opacity(0.2), radius: 10)
                                )
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    .padding()
                }
                
            }
            
            
        }.edgesIgnoringSafeArea(.all)
    }
    
    func checkPourCompletion(){
        if TWBowlOpacity == 0.0{
            PourComplete = true
        }
    }
    
    func checkGoalCompletion(){
        if strainerIndex == strainerImages.count - 1{
            GoalComplete = true
        }
    }
    
}

