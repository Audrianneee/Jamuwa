import SwiftUI
import AVFoundation

struct KunyitAgame: View{
    @State private var isShowingSheet = false
    @State private var SugarOffset = CGSize.zero
    @State private var SugarOpacity = 1.0
    @State private var KunyitOffset = CGSize.zero
    @State private var KunyitOpacity = 1.0
    @State private var SaltOffset = CGSize.zero
    @State private var SaltOpacity = 1.0
    @State private var WaterOffset = CGSize.zero
    @State private var WaterOpacity = 1.0
    @State private var TamarindOffset = CGSize.zero
    @State private var TamarindOpacity = 1.0
    @State private var PeeledTOffset = CGSize.zero
    @State private var PeeledTOpacity = 1.0
    @State private var PotOffset = CGSize.zero
    @State private var PotOpacity = 1.0
    @State private var GratedTOffset = CGSize.zero
    @State private var GratedTOpacity = 1.0
    @State private var isShowFire = false
    @State private var isShowPot = false
    @State private var putComplete = false
    @State private var boilComplete = false
    @State private var cutComplete = false
    @State private var bowlComplete = false
    @State private var isLongPressed = false
    @State private var isGratedTShown = false
    @State private var showCVKA = false
    @State private var showKAS = false
    
    var body: some View{
        ZStack {
            Image("KAgamebg")
                .resizable()
                .scaledToFill()
            
            Button(action: {
                isShowingSheet.toggle()
            }) {
                Text("INSTRUCTIONS")
                    .fontWeight(.bold)
                    .font(.system(size: 20))
                    .foregroundColor(.brown)
            }.position(x:1080,y:80)
            .sheet(isPresented: $isShowingSheet,
                   onDismiss: didDismiss) {
                VStack {
                    Text("Instructions")
                        .font(.system(size:50))
                        .fontWeight(.bold)
                        .foregroundColor(.brown)
                    Text("""
                        1. Grate the turmeric
                        Hint : long press the grater and tap the bowl
                    
                    
                        2. Peel the tamarind
                    
                    
                        3. Boil the sugar, peeled tamarind, grated turmeric, and a pinch of salt with water
                    
                    
                    
                        4. Put the pot into the bowl after it finish cooking
                    """)
                    .padding(50)
                    .font(.system(size:20))
                    .foregroundColor(.brown)
                    .fontWeight(.bold)
                    Button("Dismiss",
                           action: { isShowingSheet.toggle() })
                    .foregroundColor(.brown)
                }
            }
            Image("Grater")
                .resizable()
                .frame(width: 460, height: 345)
                .position(x: 575, y: 425)
            
            Image("CuttingBoard")
                .resizable()
                .frame(width: 400, height: 300)
                .position(x: 950,y: 350)
            
            Image("EmptyBowl")
                .resizable()
                .frame(width: 400, height: 300)
                .position(x: 600,y: 715)
            
            if boilComplete {
                ZStack{
                    if isShowFire && isShowPot {
                        Image("Pot")
                            .resizable()
                            .frame(width: 600, height: 450)
                            .position(x: 960, y: 670)
                            .onAppear(){
                                DispatchQueue.main.asyncAfter(deadline: .now() + 5){
                                    isShowPot = false
                                }
                            }
                        Image("flame") 
                            .resizable()
                            .frame(width: 700, height: 500)
                            .position(x: 960, y: 660)
                            .onAppear(){
                                DispatchQueue.main.asyncAfter(deadline: .now() + 5){
                                    isShowFire = false
                                }
                            }
                    }else{
                        Image("SmokePot")
                            .resizable()
                            .frame(width: 600, height: 450)
                            .position(x: 960, y: 650)
                            .opacity(PotOpacity)
                            .offset(PotOffset)
                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        self.PotOffset = value.translation
                                    }
                                    .onEnded { value in
                                        let dropArea = CGRect(x: 575, y: 600, width: 300, height: 300)
                                        if dropArea.contains(value.location) {
                                            withAnimation {
                                                self.PotOpacity = 0.0
                                                checkBowlCompletion()
                                            }
                                        }
                                        self.PotOffset = .zero
                                    }
                            )
                        
                    }
                }.onAppear{
                    isShowFire = true
                    isShowPot = true
                }
            }else{
                Image("Pot")
                    .resizable()
                    .frame(width: 600, height: 450)
                    .position(x: 960, y: 670)
            }
            
            Image("Kunyit")
                .resizable()
                .frame(width: 300,height: 240)
                .position(x: 300,y: 350)
                .opacity(KunyitOpacity)
                .offset(KunyitOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.KunyitOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 500, y: 250, width: 400, height: 400)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.KunyitOpacity = 0.0
                                    checkPutCompletion()
                                }
                            }
                            self.KunyitOffset = .zero
                        }
                    
                )
            
            Image("Tamarind")
                .resizable()
                .frame(width: 300,height: 240)
                .position(x: 150,y: 350)
                .opacity(TamarindOpacity)
                .offset(TamarindOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.TamarindOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 885, y: 300, width: 400, height: 300)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.TamarindOpacity = 0.0
                                    checkCutCompletion()
                                }
                            }
                            self.TamarindOffset = .zero
                        }
                    
                )
            
            Image("Sugar")
                .resizable()
                .frame(width: 300,height: 240)
                .position(x: 225,y: 500)
                .opacity(SugarOpacity)
                .offset(SugarOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.SugarOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 885, y: 600, width: 300, height: 300)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.SugarOpacity = 0.0
                                    checkBoilCompletion()
                                }
                            }
                            self.SugarOffset = .zero
                        }
                    
                )
            
            Image("Salt")
                .resizable()
                .frame(width: 200,height: 150)
                .position(x: 300,y: 600)
                .opacity(SaltOpacity)
                .offset(SaltOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.SaltOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 885, y: 600, width: 300, height: 300)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.SaltOpacity = 0.0
                                    checkBoilCompletion()
                                }
                            }
                            self.SaltOffset = .zero
                        }
                    
                )
            
            Image("Water")
                .resizable()
                .frame(width: 300,height: 240)
                .position(x: 150,y: 700)
                .opacity(WaterOpacity)
                .offset(WaterOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.WaterOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 885, y: 600, width: 300, height: 300)
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.WaterOpacity = 0.0
                                    checkBoilCompletion()
                                }
                            }
                            self.WaterOffset = .zero
                        }
                    
                )
            
            if cutComplete {
                Image("PeeledTamarind")
                    .resizable()
                    .frame(width: 300, height: 225)
                    .position(x: 950,y: 350)
                    .opacity(PeeledTOpacity)
                    .offset(PeeledTOffset)
                    .gesture(
                        DragGesture()
                            .onChanged { value in 
                                self.PeeledTOffset = value.translation
                            }
                            .onEnded { value in
                                let dropArea = CGRect(x: 885, y: 600, width: 300, height: 300)
                                if dropArea.contains(value.location) {
                                    withAnimation {
                                        self.PeeledTOpacity = 0.0
                                        checkBoilCompletion()
                                    }
                                }
                                self.PeeledTOffset = .zero
                            }
                        
                    )
            }
            
            if bowlComplete{
                Image("KABowl")
                    .resizable()
                    .frame(width: 400, height: 300)
                    .position(x: 600,y: 715)
                
                if showKAS{
                    KASView()
                        .onAppear{
                            isLongPressed = false
                            putComplete = false
                        }
                }
                VStack {
                    Button("Show Congratulations") {
                        showCVKA = true
                    }
                    .padding()
                    .position(x: 100, y: 100)
                    .opacity(0.0)
                }
                .sheet(isPresented: $showCVKA) {
                    CVKAView(showCVKA: $showCVKA, showKAS: $showKAS)
                }
                
            }

            
            if putComplete {
                VStack {
                    if isLongPressed {
                        Image("GraterF") 
                            .resizable()
                            .frame(width: 460, height: 345)
                            .position(x: 575, y: 425)
                            .onTapGesture {
                                isGratedTShown.toggle()
                            }
                    } else {
                        Image("Grater")
                            .resizable()
                            .frame(width: 460, height: 345)
                            .position(x: 575, y: 425)
                            .gesture(
                                LongPressGesture(minimumDuration: 1.5) 
                                    .onEnded { _ in
                                        isLongPressed.toggle()
                                    }
                            )
                    }
                }
            }
                
            if isGratedTShown {
                Image("GratedT")
                    .resizable()
                    .frame(width: 300, height: 225)
                    .position(x: 600, y: 425)
                    .opacity(GratedTOpacity)
                    .offset(GratedTOffset)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                self.GratedTOffset = value.translation
                            }
                            .onEnded { value in
                                let dropArea = CGRect(x: 885, y: 600, width: 300, height: 300)
                                if dropArea.contains(value.location) {
                                    withAnimation {
                                        self.GratedTOpacity = 0.0
                                        checkBoilCompletion()
                                    }
                                }
                                self.GratedTOffset = .zero
                            }
                        
                    )
            }
            
        }.edgesIgnoringSafeArea(.all)
            .onAppear {
                isShowingSheet = true 
            }
    }
    
    
    func checkCutCompletion(){
        if TamarindOpacity == 0.0 {
            cutComplete = true
        }
    }
    
    func checkBoilCompletion(){
        if PeeledTOpacity == 0 && SugarOpacity == 0 && SaltOpacity == 0 && WaterOpacity == 0 && GratedTOpacity == 0{
            boilComplete = true
        }
    }
    
    func checkBowlCompletion() {
        if PotOpacity == 0.0 {
            bowlComplete = true
            showCVKA = true
        }
    }
    
    func checkPutCompletion(){
        if KunyitOpacity == 0{
            putComplete = true
        }
    }
    func didDismiss() {
    }

}

