import SwiftUI
import AVFoundation

struct BKS: View {
    @State private var BKBowlOffset = CGSize.zero
    @State private var BKBowlOpacity = 1.0
    @State private var PourComplete = false
    @State private var strainerIndex = 0
    @State private var GoalComplete = false
    @State private var showThirdView = false
    
    let strainerImages = ["Strainer5", "Strainer4", "Strainer3", "Strainer2", "Strainer1","EmptyStrainer"]
    let BKImages = ["EmptyCup","BK1","BK2","BK3","BK4","BK5"]
    
    var body: some View {
        ZStack{
            Image("BKSbg")
                .resizable()
                .scaledToFill()
            
            Image("EmptyStrainer")
                .resizable()
                .frame(width: 960, height: 720)
                .position(x: 790, y: 225)
            
            Image("BKBowl")
                .resizable()
                .frame(width: 600,height: 450)
                .position(x: 245,y: 550)
                .opacity(BKBowlOpacity)
                .offset(BKBowlOffset)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            self.BKBowlOffset = value.translation
                        }
                        .onEnded { value in
                            let dropArea = CGRect(x: 575, y: 150, width: 300, height: 300) 
                            if dropArea.contains(value.location) {
                                withAnimation {
                                    self.BKBowlOpacity = 0.0
                                    checkPourCompletion()
                                }
                            }
                            self.BKBowlOffset = .zero
                        }
                    
                )
            Image("EmptyCup")
                .resizable()
                .frame(width: 900, height: 675)
                .position(x: 680, y: 500)
            
            if PourComplete{
    
                    Image(strainerImages[strainerIndex])
                        .resizable()
                        .frame(width: 960, height: 720)
                        .position(x: 790, y: 225)
                        .onTapGesture {
                            if strainerIndex < strainerImages.count - 1 {
                                strainerIndex += 1
                                checkGoalCompletion()
                            }
                        }
                    Image(BKImages[strainerIndex])
                        .resizable()
                        .frame(width: 900, height: 675)
                        .position(x: 680, y: 500)
                        .offset()
                
                
            }
            

            if GoalComplete {
                ZStack{
                    Image("BKLast")
                        .resizable()
                        .frame(width: 700, height: 700)
                    VStack {
                        Text("Congratulations🥳")
                            .font(.largeTitle)
                        Spacer().frame(height: 50)
                        Text("Here is your Jamu Beras Kencur")
                            .font(.largeTitle)
                        Spacer().frame(height:450)
                        NavigationLink(destination: ThirdView()) {
                            Text("Make another Jamu ?")
                                .font(.system(size: 30))
                                .foregroundColor(.white)
                                .padding()
                                .padding(.horizontal, 20)
                                .background(
                                    Color.brown
                                        .cornerRadius(10)
                                        .shadow(
                                            color: Color.black.opacity(0.2), radius: 10)
                                )
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                    .padding()
                }
                        
            }

            
        }.edgesIgnoringSafeArea(.all)
    }
    
    func checkPourCompletion(){
        if BKBowlOpacity == 0.0{
            PourComplete = true
        }
    }
    
    func checkGoalCompletion(){
        if strainerIndex == strainerImages.count - 1{
            GoalComplete = true
        }
    }
    
}


