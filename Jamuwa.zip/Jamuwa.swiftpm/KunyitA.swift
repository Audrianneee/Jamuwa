import SwiftUI
import AVFoundation

struct KunyitA: View {
    @State private var isKunyitAgamePresented = false
    
    var body: some View {
            VStack {
                Image("KAbg") 
                    .resizable()
                    .scaledToFill()
                    .overlay(
                        VStack {
                            NavigationLink(destination: KunyitAgame()){
                                Text("Next".uppercased())
                                    .font(.system(size: 40))
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .padding(.horizontal, 20)
                                    .background(
                                        Color.brown
                                            .cornerRadius(10)
                                            .shadow(
                                                color: Color.black.opacity(0.2), radius: 10)
                                    )
                                    .scaleEffect(isKunyitAgamePresented ? 1.2 : 1.0)
                                    .onAppear {
                                        withAnimation(Animation.easeInOut(duration: 1.5).repeatForever()) {
                                            self.isKunyitAgamePresented.toggle()
                                        }
                                    }
                                    .padding(20)
                                    .padding(.bottom,100)
                            }.position(x:900,y:-130)
                        }.padding(.bottom)
                            .padding(.top,750)
                    )
            } .edgesIgnoringSafeArea(.all)
    }
}
