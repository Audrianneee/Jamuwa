import SwiftUI
import AVFoundation

class AudioManager: ObservableObject {
    var player: AVAudioPlayer?
    
    init() {
        if let path = Bundle.main.path(forResource: "Jamuwa", ofType: "mp3") {
            let url = URL(fileURLWithPath: path)
            do {
                player = try AVAudioPlayer(contentsOf: url)
                player?.numberOfLoops = -1
                player?.play()
            } catch {
                print("Error loading audio file:", error.localizedDescription)
            }
        } else {
            print("Audio file not found")
        }
    }
}

struct ContentView: View {
    @State private var isSecondViewPresented = false
    @StateObject var audioManager = AudioManager()
    
    var body: some View {
        NavigationView {
            VStack {
                Image("BGImage") 
                    .resizable()
                    .scaledToFill()
                    .overlay(
                        VStack {
                            NavigationLink(destination: SecondView()){
                                Text("PLAY".uppercased())
                                    .font(.system(size: 50))
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .padding(.horizontal, 20)
                                    .background(
                                        Color.brown
                                            .cornerRadius(10)
                                            .shadow(
                                                color: Color.black.opacity(0.2), radius: 10)
                                    )
                                    .scaleEffect(isSecondViewPresented ? 1.2 : 1.0)
                                    .onAppear {
                                        withAnimation(Animation.easeInOut(duration: 1.5).repeatForever()) {
                                            self.isSecondViewPresented.toggle()
                                        }
                                    }
                            }.padding(20)
                                .padding(.bottom,100)
                        }.padding(.bottom)
                            .padding(.top,650)
                    )
            } .edgesIgnoringSafeArea(.all)
        } .navigationViewStyle(StackNavigationViewStyle())
    }
}
